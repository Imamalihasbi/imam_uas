import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { Router } from '@angular/router';
import axios from 'axios';

@Component({
  selector: 'app-user',
  templateUrl: './user.page.html',
  styleUrls: ['./user.page.scss'],
})
export class UserPage  {

 
  public  MahasiswaDataBaru:any = [];

  public username:any="";
  public password:any="";
  public nama:any="";
  public status:any="";
  
  

  constructor(
    public modalCtrl: ModalController, private router:Router
  ) {
    this.getData();
    
  }
  Getdata(){
    this.router.navigate(['/tabs/tab1'])
  }
  // ngOnInit() {
  // }
  async getData() {
    try {
      const res = await axios.post('https://praktikum-cpanel-unbin.com/api_imam/uas/get.fee.data.php');
      this.MahasiswaDataBaru = res.data.result;
      console.log(this.MahasiswaDataBaru);
  
      }catch(err){
        console.log(err);
      }
    }


    

}
